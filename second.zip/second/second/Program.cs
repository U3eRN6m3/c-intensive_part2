﻿using System;

namespace second
{
    public abstract class GeometricFigure
    {
        public abstract double GetFigureArea();
        public abstract override string ToString();

        public void Print()
        {
            Console.WriteLine(this.ToString());
        }
    }

    class Rectangle : GeometricFigure
    {
        private double m_height;
        private double m_width;

        public double Height
        {
            get
            {
                return m_height;
            }

            set
            {
                m_height = value;
            }
        }

        public double Width
        {
            get
            {
                return m_width;
            }

            set
            {
                m_width = value;
            }
        }

        public Rectangle(double height, double width)
        {
            m_height = height;
            m_width = width;
        }

        public override double GetFigureArea()
        {
            return m_height * m_width;
        }

        public override string ToString()
        {
            return $"FigureName: Rectangle\nWidth: {m_width}\nHeight: {m_height}";
        }
    }

    class Square : GeometricFigure
    {
        private double m_side;

        public Square(double side)
        {
            m_side = side;
        }

        public override double GetFigureArea()
        {
            return m_side * m_side;
        }

        public override string ToString()
        {
            return $"FigureName: Square\nSide: {m_side}";
        }
    }

    class Circle : GeometricFigure
    {
        private double m_radius;
        private readonly double pi = 3.14;

        public double Radius
        {
            get
            {
                return m_radius;
            }

            set
            {
                m_radius = value;
            }
        }

        public Circle(double radius)
        {
            m_radius = radius;
        }

        public override double GetFigureArea()
        {
            return pi * m_radius * m_radius;
        }

        public override string ToString()
        {
            return $"FigureName: Circle\nRadius: {m_radius}";
        }
    }

    class Program
    {
        static void Main()
        {
            GeometricFigure[] figures =
            {
                new Rectangle(5, 5),
                new Square(40),
                new Circle(6)
            };

            foreach (var figure in figures)
            {
                figure.Print();
                Console.WriteLine($"Area: {figure.GetFigureArea()}");
                Console.WriteLine();
            }


            Console.ReadKey();
        }
    }
}
