﻿using System;

namespace first
{
    class Program
    { 
        /// <summary>
        /// Вводим коэффициент уравнения с клавиатуры
        /// </summary>
        /// <returns>Коэффициент</returns>
        static double GetCorrectOdd()
        {
            var res = double.TryParse(Console.ReadLine(), out var temp);

            if (res == false)
            {
                Console.WriteLine("You have typed odd wrongly. Please, try again.");
                temp = GetCorrectOdd();
            }

            return temp;
        }

        /// <summary>
        /// Выводит текст в консоль с заданным цветом
        /// </summary>
        /// <param name="text">Текст для вывода</param>
        /// <param name="a">Цвет текста</param>
        static void printColoredText(string text, ConsoleColor a)
        {
            Console.ForegroundColor = a;
            Console.WriteLine(text);
            Console.ResetColor();
        }

        /// <summary>
        /// Получает решение биквадратного уравнения
        /// </summary>
        /// <param name="a">Первый коэффициент</param>
        /// <param name="b">Второй коэффициент</param>
        /// <param name="c">Третий коэффициент</param>
        static void GetSolution(double a, double b, double c)
        {
            double d = b*b - 4 * a * c;
            if (d < 0)
                printColoredText("There are no roots for the equation", ConsoleColor.Red);
            else if (d == 0)
            {
                double root = -b / (2 * a);
                if (root == 0)
                    printColoredText("0", ConsoleColor.Green);
                else
                    printColoredText($"{-Math.Sqrt(root)}, {Math.Sqrt(root)}", ConsoleColor.Green);
            }
            else
            {
                double root1 = (-b + Math.Sqrt(d)) / (2 * a);
                double root2 = (-b - Math.Sqrt(d)) / (2 * a);

                if (root1 < 0)
                    printColoredText("There are no roots for the equation", ConsoleColor.Red);
                else if (root2 < 0)
                {
                    if (root1 == 0)
                        printColoredText("0", ConsoleColor.Green);
                    else
                        printColoredText($"{-Math.Sqrt(root1)}, {Math.Sqrt(root1)}", ConsoleColor.Green);
                }   
                else
                {
                    if (root1 == 0)
                        printColoredText($"0, {-Math.Sqrt(root2)}, {Math.Sqrt(root2)}", ConsoleColor.Green);
                    else if (root2 == 0)
                        printColoredText($"0, {-Math.Sqrt(root1)}, {Math.Sqrt(root1)}", ConsoleColor.Green);
                    else
                        printColoredText($"{-Math.Sqrt(root1)}, {Math.Sqrt(root1)}, {-Math.Sqrt(root2)}, {Math.Sqrt(root2)}",
                                            ConsoleColor.Green);
                }
            }
        }

        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                var a = GetCorrectOdd();
                var b = GetCorrectOdd();
                var c = GetCorrectOdd();

                GetSolution(a, b, c);
            }
            else if (args.Length == 3)
            {
                var res1 = double.TryParse(args[0], out var a);
                var res2 = double.TryParse(args[1], out var b);
                var res3 = double.TryParse(args[2], out var c);

                if (res1 == true && res2 == true && res3 == true)
                    GetSolution(a, b, c);
                else
                    throw new Exception("Check command-line arguments");
            }
            else
                throw new Exception("You need to type 3 arguments (odds of the equation");


            Console.ReadKey();
        }
    }
}
